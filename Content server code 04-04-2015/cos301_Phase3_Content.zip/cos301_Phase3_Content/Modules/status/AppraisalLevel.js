/**
 * Created by Abrie on 2015/03/26.
 */

/**
 *
 * @param _name String
 * @param _icon Buffer
 * @constructor
 */
function AppraisalLevel(_name,_icon){
    this.name = _name;
    this.icon = _icon;
}

module.exports.AppraisalLevel = AppraisalLevel;